<?php echo e($slot); ?>

<?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>