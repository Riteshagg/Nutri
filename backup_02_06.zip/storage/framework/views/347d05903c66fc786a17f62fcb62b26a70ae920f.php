<script src="<?php echo asset('assets/vendor/bootstrap/js/bootstrap.bundle.js'); ?>"></script>
<script src="<?php echo asset('assets/vendor/slimscroll/jquery.slimscroll.js'); ?>"></script>
<script src="<?php echo asset('assets/vendor/parsley/parsley.js'); ?>"></script>
<script src="<?php echo asset('assets/libs/js/main-js.js'); ?>"></script>

<script src="https://code.jquery.com/ui/1.9.2/jquery-ui.min.js"></script>
<script>
    $('#form').parsley();
</script><?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/layouts/partials/script.blade.php ENDPATH**/ ?>