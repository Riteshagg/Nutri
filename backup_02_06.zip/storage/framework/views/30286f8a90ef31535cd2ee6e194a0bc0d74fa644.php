

<?php $__env->startSection('content'); ?>

    <div class="container-fluid  dashboard-content">

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Gerir Consultas</h2>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-header d-flex">
                        <h4 class="card-header-title">Listagem de Consultas</h4>

                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php if(Auth::user()->hasRole('Admin')): ?>
                            <div class="form-group row" id="patientNutritionistAppDropdownRow">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Selecionar
                                    Nutricionista</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <?php
                                        $sel = !(isset($_GET) && isset($_GET['nid'])) ? "selected" : "";
                                    ?>

                                    <select class="form-control" name="nutritionist" id="nutritionistSelect">
                                        <option value="" disabled <?php echo e($sel); ?>> Selecionar Nutricionista</option>
                                        <?php $__currentLoopData = $nutritionists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nutritionist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $selected = ((isset($_GET['nid'])) && $_GET['nid'] == $nutritionist->id )? "selected" : "";
                                            ?>
                                            <option value="<?php echo e($nutritionist->id); ?>" <?php echo e($selected); ?>><?php echo e($nutritionist->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <script>
                                    $("#nutritionistSelect").on('change', function (event) {
                                        let url = new URL(window.location.href);
                                        url.searchParams.set("nid", event.target.value);
                                        url.searchParams.delete("id");
                                        window.location.href = url.href
                                    })
                                </script>
                            </div>
                        <?php endif; ?>

                        <?php if(Auth::user()->hasRole('Nutritionist') || (count($patients)) ): ?>
                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Selecionar
                                    Cliente</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <?php $sel = !(isset($_GET) && isset($_GET['id'])) ? "selected" : ""; ?>
                                    <select class="form-control" name="patient" id="patientSelect">
                                        <option value="" disabled <?php echo e($sel); ?> > Selecionar Cliente</option>
                                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient_array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $selected = ((isset($_GET['uid'])) && $_GET['uid'] == $patient_array->user->id )? "selected" : "";
                                            ?>
                                            <option value="<?php echo e($patient_array->user->id); ?>" <?php echo e($selected); ?>><?php echo e($patient_array->user->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <script>
                                        $("#patientSelect").on('change', function (event) {
                                            let url = new URL(window.location.href);
                                            url.searchParams.set("uid", event.target.value)
                                            window.location.href = url.href
                                        })
                                    </script>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(isset($_GET) && isset($_GET['uid'])): ?>
                            <table id="appointmentWholeTable" class="display table table-hover table-striped"
                                   style="width:100%">
                                <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Peso (Kg)</th>
                                    <th>Massa Muscular (Kg)</th>
                                    <th>Massa Gorda (Kg)</th>
                                    <th>Total Água</th>
                                    <th>Gordura Visceral (g/cm²)</th>
                                    <th>Rácio Cintura/Anca</th>
                                </tr>
                                </thead>

                                <tbody id="appointmentTableBody">

                                <?php $__currentLoopData = $appointmentlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr data-appointment-id='<?php echo e($appointment->id); ?>'
                                        onclick='editOnlineAppointment(<?php echo e($appointment->id); ?>)' style='cursor: pointer'>
                                        <td><?php echo e($appointment->date); ?></td>
                                        <td><?php echo e($appointment->weight); ?></td>
                                        <td><?php echo e($appointment->muscleMass); ?></td>
                                        <td><?php echo e($appointment->fatMass); ?></td>
                                        <td><?php echo e($appointment->totalWater); ?></td>
                                        <td><?php echo e($appointment->visceralFat); ?></td>
                                        <td><?php echo e($appointment->hipWaistRatio); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Data</th>
                                    <th>Peso (Kg)</th>
                                    <th>Massa Muscular (Kg)</th>
                                    <th>Massa Gorda (Kg)</th>
                                    <th>Total Água</th>
                                    <th>Gordura Visceral (g/cm²)</th>
                                    <th>Rácio Cintura/Anca</th>
                                </tr>
                                </tfoot>
                            </table>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if((isset($_GET) && isset($_GET['uid']) && isset($_GET['nid'])) || (isset($_GET) && isset($_GET['uid']) && Auth::user()->hasRole('Nutritionist') )): ?>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header">Adicionar Consulta</h5>
                    <div class="card-body">
                        <?php
                            if (Auth::user()->hasRole('Admin')) {
                                $qs = "?" . http_build_query(["uid" => trim($_GET['uid']), "nid" => trim($_GET['nid'])]);
                            } else {
                                $qs = "?" . http_build_query(["uid" => trim($_GET['uid'])]);
                            }
                        ?>

                        <form action="/backend/addAppointment.php<?php echo e($qs); ?>" method="post" data-parsley-validate>
                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Data da Consulta</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input name="appDate" required class="form-control" dateformat="d M y" type="date"/>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Peso (Kg)</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="weight" placeholder="Introduza o Peso (Kg)" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Massa Muscular (Kg)</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="mm" placeholder="Introduza a Massa Muscular em Kg" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Massa Gorda (Kg)</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="fm" placeholder="Introduza a Massa Gorda em Kg" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Total de Água (Kg)</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="tw" placeholder="Introduza o Total de Água" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Gordura Visceral (g/cm²)</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="vf" placeholder="Introduza a Gordura Visceral" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right"><abbr title="Em decimal">Rácio Cintura/Anca</abbr></label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="hw" placeholder="Introduza o Rácio Cintura/Anca" class="form-control" data-parsley-pattern="[0-9]*([.,]?[0-9]*)">
                                </div>
                            </div>

                            <div class="form-group row text-right">
                                <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                    <button type="submit" class="btn btn-space btn-primary">Gravar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div id="appointmentChart">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="chartWeight"></div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="chartmm"></div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="chartfm"></div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="charttw"></div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="chartvf"></div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card border-4 border-top border-top-primary" style="padding: 10px  ">
                        <div id="charthw"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>

    <script>
        // parse json as it was before
        window.chartData = array();

        var weight = [];
        var date = [];
        var average = [];
        var mm = [];
        var fm = [];
        var tw = [];
        var vf = [];
        var hw = [];
        var sum = 0;
        for (var i = 0; i < window.chartData.length; i++) {
            weight.push(Number(window.chartData[i].weight));
            mm.push(Number(window.chartData[i].mm));
            fm.push(Number(window.chartData[i].fm));
            tw.push(Number(window.chartData[i].tw));
            vf.push(Number(window.chartData[i].vf));
            hw.push(Number(window.chartData[i].hw));
            date.push(window.chartData[i].date);
        }

        function highchart(id, title, yText, xText, yName1, yData1, yName2, yData2, xData) {
            Highcharts.chart(id, {
                title: {text: title},
                yAxis: {title: {text: yText}},
                xAxis: {categories: xData, title: {text: xText}},
                credits: {enabled: false},
                series: [
                    {name: yName1, data: yData1, color: '#1f8677'}
                ],
                responsive: {
                    rules: [{condition: {maxWidth: 500},}]
                }
            });
        }

        //build Charts
        highchart("chartWeight", "Variação do Peso", "Peso (Kg)", "Data da consulta", "Peso", weight, "Média", average, date);
        highchart("chartfm", "Variação da Massa Gorda", "Massa Gorda (Kg)", "Data da Consulta", "Gordura", fm, "Média", average, date);
        highchart("chartmm", "Variação da Massa Muscular", "Massa Muscular (Kg)", "Data da Consulta", "Músculo", mm, "Média", average, date);
        highchart("charttw", "Variação do Total de Água", "Total Água", "Data da Consulta", "Total Água", tw, "Média", average, date);
        highchart("chartvf", "Variação da Gordura Visceral", "Gordura Visceral (g/cm²)", "Data da Consulta", "Gordura Visceral", vf, "Média", average, date);
        highchart("charthw", "Variação do Rácio Cintura/Anca", "Valores", "Data da Consulta", "Racio Cintura/Anca", hw, "Média", average, date);

        $(document).ready(function () {
            $.fn.dataTable.moment('DD/MM/YYY');
            $('#appointmentWholeTable').DataTable({
                //orderCellsTop: true,
                fixedHeader: true,
                autoFill: true,
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/pages/appointment.blade.php ENDPATH**/ ?>