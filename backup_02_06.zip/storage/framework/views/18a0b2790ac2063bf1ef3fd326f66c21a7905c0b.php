<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>

<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger alert-outline alert-dismissible fade show" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true" class="la la-close"></span>
        </button>
    </div>
<?php endif; ?>


<?php if($errors->all()): ?>
    <div class="alert alert-danger alert-outline alert-dismissible fade show" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?> <br/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true" class="la la-close"></span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/layouts/message.blade.php ENDPATH**/ ?>