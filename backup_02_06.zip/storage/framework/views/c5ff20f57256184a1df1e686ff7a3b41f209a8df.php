
<?php $__env->startSection('content'); ?>

    <div class="container-fluid  dashboard-content">

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Ver Clientes</h2>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="form-group">
                            <table class="display table table-hover table-striped" style="width:100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nome</th>
                                    <th>Telefone</th>
                                    <th>Data de Nascimento</th>
                                    <th>Email</th>
                                    <?php if(Auth::user()->hasRole('Admin')): ?>
                                    <th>Nutricionista</th>
                                    <th>Activo</th>
                                    <?php endif; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-patient-id='<?php echo e($patient->user->id); ?>' onclick='editPatient(<?php echo e($patient->user->id); ?>)' style="cursor: pointer">
                                        <td><?php echo e(++$i); ?></td>
                                        <td><?php echo e($patient->user->name); ?></td>
                                        <td><?php echo e($patient->user->phone); ?></td>
                                        <td><?php echo e($patient->user->dob); ?></td>
                                        <td><?php echo e($patient->user->email); ?></td>
                                        <?php if(Auth::user()->hasRole('Admin')): ?>
                                            <th>Nutricionista</th>
                                            <th><?php echo e(($patient->user->status == 1)? "Activo" : "Inactivo"); ?></th>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>
                                </tfoot>
                            </table>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal" id="patientModal" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="smallmodalLabel">Editar Cliente</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">


                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Id Cliente: </label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input type="text" required="" id="mpatientId" class="form-control" disabled>

                                </div>
                            </div>

                            <?php if(count($nutritionists)): ?>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Selecione o Nutricionista</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <select class="form-control" id="patientNutritionistDropdown" name="nutritionistSelect">
                                            <option value="" disabled selected>Selecionar Nutricionista</option>

                                            <?php $__currentLoopData = $nutritionists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nutritionist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($nutritionist->id); ?>" ><?php echo e($nutritionist->name); ?></option>;
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php echo e(Form::hidden( 'nutritionistSelect', Auth::id() )); ?>

                            <?php endif; ?>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Nome do Cliente</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input type="text" required="" id="mpName" placeholder="Introduza o nome do Cliente" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Telefone</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input type="number" required="" id="mpPhone" placeholder="Introduza o Telefone" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Data de nascimento</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input id="mpDate" class="form-control" dateformat="d M y" type="date"/>
                                    <span class="mpDate_span" id="mpDate_span" style="pointer-events: none;"></span>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Email</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input type="text" required="" id="mpEmail" placeholder="Intoduza o email" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Utilizador</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <input type="text" required="" id="mpUsername" placeholder="Introduza o utilizador do Cliente" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Activo</label>
                                <div class="col-12 col-sm-10 col-lg-8">
                                    <select name="pActive" id="pActive" class="form-control" required>
                                        <option value="0">Inactivo</option>
                                        <option value="1">Activo</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row text-right">
                                <div class="col col-sm-2 col-lg-3 ">
                                    <button class="btn btn-space btn-danger" onclick="patientDelete()">Eliminar</button>
                                </div>

                                <div class="col col-sm-10 col-lg-8 offset-sm-1 offset-lg-0">
                                    <button type="button" onclick="patientUpdate()" class="btn btn-space btn-success">Actualizar</button>

                                </div>
                            </div>

                        </div>
                    </div>

                </div><!--Modal Body-->
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
    <script>
        dataTablePatient();
    </script>
    <script src="<?php echo asset('js/patient.js'); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/pages/patientlist.blade.php ENDPATH**/ ?>