<?php $__env->startSection('content'); ?>

    <div class="container-fluid  dashboard-content">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Nome Cliente</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">

                    <div class="card-body">
                        <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('patientstore')); ?>" method="post" id="form">
                            <?php echo csrf_field(); ?>

                            <?php if(count($nutritionists)): ?>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Selecione o Nutricionista</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <select class="form-control" id="patientNutritionistDropdown" name="nutritionistSelect">
                                            <option value="" disabled selected>Selecionar Nutricionista</option>

                                            <?php $__currentLoopData = $nutritionists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nutritionist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($nutritionist->id); ?>" ><?php echo e($nutritionist->name); ?></option>;
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php echo e(Form::hidden( 'nutritionistSelect', Auth::id() )); ?>

                            <?php endif; ?>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Nome</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="text" required name="name" id="name" placeholder="Introduza o Nome" class="form-control" value="<?php echo e(old('name')); ?>" >
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Telefone</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="tel" required name="phone" id="phone" placeholder="Introduza o Telefone" class="form-control" maxlength="9" >
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Data Nascimento</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input id="dob" required name="dob" class="form-control" dateformat="d M Y" type="date" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Email</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="email" required name="email" id="email" placeholder="Introduza o Email" class="form-control" >
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Password</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input type="password" required name="password" id="password" placeholder="Introduza a Password" class="form-control" >
                                </div>
                            </div>

                            <div class="form-group row text-right">
                                <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                    <button type="submit" class="btn btn-space btn-primary">Gravar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/pages/patientadd.blade.php ENDPATH**/ ?>