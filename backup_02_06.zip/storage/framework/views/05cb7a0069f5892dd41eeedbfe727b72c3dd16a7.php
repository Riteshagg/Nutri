<div class="footer" style="position: fixed; bottom: 0">
    <div class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    ©<?= date("Y") ?> Nutri4Solutions. Made with ❤ by
                    <a href="https://www.sigmasmile.pt">Sigma Smile</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/layouts/partials/footer.blade.php ENDPATH**/ ?>