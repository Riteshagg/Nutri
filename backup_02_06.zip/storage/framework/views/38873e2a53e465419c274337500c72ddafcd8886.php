<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">
                        Menu
                    </li>
                    <li class="nav-item " id="dashboardMenu">
                        <a class="nav-link " href="<?php echo e(URL('dashboard')); ?>">
                            <i class="fa fa-fw fa-user-circle"></i>Dashboard</a>
                    </li>

                    <?php if(Auth::user()->hasRole('Admin')): ?>
                    <li class="nav-item" id="nutritionistMenu">
                        <a class="nav-link" href="<?php echo e(URL('nutritionist-add')); ?>">
                            <i class="fa fa-fw fa-briefcase-medical"></i>Adicionar Nutricionista</a>
                    </li>
                    <li class="nav-item" id="nutritionistListMenu">
                        <a class="nav-link" href="<?php echo e(URL('nutritionist-list')); ?>">
                            <i class="fa fa-fw fa-file-medical-alt"></i>Ver Nutricionistas</a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item " id="patientMenu">
                        <a class="nav-link" href="<?php echo e(URl('patients-add')); ?>"><i class="fa fa-fw fa-user-plus"></i>Adicionar Cliente</a>
                    </li>

                    <li class="nav-item " id="patientListMenu">
                        <a class="nav-link " href="<?php echo e(URl('patients')); ?>"><i class="fa fa-fw fa-th-list"></i>Ver Clientes</a>
                    </li>

                    <li class="nav-item " id="appointmentMenu">
                        <a class="nav-link" href="<?php echo e(URL('appointments')); ?>"><i class="fa fa-fw fa-briefcase-medical"></i>Gerir
                            Consultas</a>
                    </li>
                    <li class="nav-item " id="onlineAppointmentMenu">
                        <a class="nav-link" href="<?php echo e(url('online-appointments')); ?>"><i class="fa fa-fw fa-briefcase-medical"></i>Gerir
                            Consultas Online</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH /var/www/vhosts/invoidea.in/httpdocs/lab3/nut_sol/resources/views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>