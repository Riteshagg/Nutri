<?php
namespace App\Http\Controllers;

use App\Nutritionist;
use App\User;
use App\Appointment;
use App\OnlineAppointment;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class AppointmentController extends Controller
{

    public function onlineAppointment( Request $request)
    {

        $nutritionists = $patient_list = $onappointment = array();

        if(Auth::user()->hasRole('Admin')) :
            $nutritionists = User::role('Nutritionist')->orderBy('id','DESC')->paginate(5);

        endif;

        if(Auth::user()->hasRole('Admin')) :
            $selectedNutritionist = trim($request->input('nid'));
        elseif(Auth::user()->hasRole('Nutritionist')):
            $selectedNutritionist = Auth::id();
        endif;

        $patients = Nutritionist::with('user')->where('nutritionistId', $selectedNutritionist)->get();

        $uid = $request->input('uid');

        if(isset($uid)) {
            $onappointment_query = OnlineAppointment::where('patientId', $uid);
            if( $onappointment_query->exists())
                $onappointment = $onappointment_query->get();
            else
                $onappointment = array();
        }

        return view('pages.onlineappointment', compact('nutritionists', 'patients', 'onappointment') );

    }

    public function appointment( Request $request)
    {

        $nutritionists = $patient_list = $appointmentlist = array();

        if(Auth::user()->hasRole('Admin')) :
            $nutritionists = User::role('Nutritionist')->orderBy('id','DESC')->paginate(5);
        endif;

        if(Auth::user()->hasRole('Admin')) :
            $selectedNutritionist = trim($request->input('nid'));
        elseif(Auth::user()->hasRole('Nutritionist')):
            $selectedNutritionist = Auth::id();
        endif;

        $patients = Nutritionist::with('user')->where('nutritionistId', $selectedNutritionist)->get();

        $uid = $request->input('uid');

        if(isset($uid)) {
            $appointment_query = Appointment::where('patientId', $uid);
            if( $appointment_query->exists())
                $appointmentlist = $appointment_query->get();
            else
                $appointmentlist = array();
        }

        return view('pages.appointment', compact('nutritionists', 'patients', 'appointmentlist') );

    }
}