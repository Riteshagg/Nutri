<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;



class NutritionistController extends Controller
{
    //


    public function index( Request $request)
    {

        $user_list_array = User::role('Nutritionist')->orderBy('id','DESC')->paginate(5);

        return view('pages.nutritionist_list', ['user_list' => $user_list_array ])->with('i', ($request->input('page', 1) - 1) * 5);

    }

    public function create()
    {
        return view('pages.nutritionist_add');
    }

    public function save_user(Request $request){

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required'
        ]);

        $password=Hash::make('123456');

        $users_detail = [
            'name'=>$request->input('name'),
            'email'=>$request->input('email'),
            'password'=>$password,
            'phone'=>$request->input('phone'),
            'dob'=>$request->input('dob'),
            'created_at'=>now(),
        ];


        $user = User::create($users_detail);
        $user->assignRole('Nutritionist');

        if($user){
            return redirect()->route('nutritionist_add')->with('success','Nutritionist created successfully !');
        }else{
            return redirect()->route('nutritionist_add')->with('error','Error !');

        }

    }

}
