<?php
namespace App\Http\Controllers;

use App\User;
use App\Nutritionist;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class PatientController extends Controller
{

    public function index(Request $request)
    {
        $data = array();

        if(Auth::user()->hasRole('Admin'))
            $data = Nutritionist::with('user')->orderBy('userId','DESC')->paginate(10);
        elseif(Auth::user()->hasRole('Nutritionist')){
            $nutritionist = Auth::id();
            $data = Nutritionist::with('user')->where('nutritionistId', $nutritionist)->orderBy('userId','DESC')->paginate(10);
        }

        if(Auth::user()->hasRole('Admin'))
            $nutritionists  = User::role('Nutritionist')->orderBy('name','DESC')->get();


        return view('pages.patientlist', compact('data', 'nutritionists'))->with('i', ($request->input('page', 1) - 1) * 5);

    }

    public function create()
    {
        $nutritionist_list = array();

        if(Auth::user()->hasRole('Admin'))
            $nutritionist_list  = User::role('Nutritionist')->orderBy('name','DESC')->get();

        return view('pages.patientadd', ['nutritionists' => $nutritionist_list ]);
    }


    public function store(Request $request)
    {

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required',
            'password' => 'required'
        ]);

        $password=Hash::make($request->input('password'));

        $users_detail = [
            'name'=>$request->input('name'),
            'email'=>$request->input('email'),
            'password'=> $password,
            'phone'=>$request->input('phone'),
            'dob'=>$request->input('dob'),
            'created_at'=>now(),
        ];

        $user = User::create($users_detail);
        $user->assignRole('Patient');

        $Nutritionist= Nutritionist::create([
                'userId' => $user->id,
                'nutritionistId' => $request->input('nutritionistSelect')
        ]);

        if($user){
            return redirect()->route('patientadd')->with('success','Patient Added successfully !');
        }else{
            return redirect()->route('patientadd')->with('error','Error !');

        }
    }

    public function ajaxHandler(Request $request)
    {
        $user = User::find($request->input('id'));

        return $user;
    }
}