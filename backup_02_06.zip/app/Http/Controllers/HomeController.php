<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Nutritionist;
use App\Appointment;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $nutritionist = array(
            'total' => User::role('Nutritionist')->count(),
            'active' => User::role('Nutritionist')->where('status', '1')->count(),
        );

        if(Auth::user()->hasRole('Admin')) :
            $patient = array(
                'total' => User::role('Patient')->count(),
                'active' => User::role('Patient')->where('status', '1')->count(),
            );
        elseif(Auth::user()->hasRole('Nutritionist')):
            $patient = array(
                'active' => Nutritionist::with('user')->where('nutritionistId', Auth::id())->count(),
            );
        endif;

        if(Auth::user()->hasRole('Admin')) :
            $appointment = array(
                'active' => Appointment::count(),
            );
        elseif(Auth::user()->hasRole('Nutritionist')):
            $appointment = array(
                'active' => Appointment::where('nutritionistId', Auth::id())->count(),
            );
        elseif(Auth::user()->hasRole('Patient')):
            $appointment = array(
                'active' => Appointment::where('patientId', Auth::id())->count(),
            );
        endif;

        return view('dashboard',  compact('nutritionist', 'patient', 'appointment'));
    }
}
