<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nutritionist extends Model
{
    protected $table = "users_to_nutritionist";

    protected $fillable = [
        'nutritionistId', 'userId'
    ];

    public function user()
    {
        return $this->belongsTo('App\User', 'userId');
    }
}
