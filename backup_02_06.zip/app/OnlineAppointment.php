<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OnlineAppointment extends Model
{
    protected $table = "online_appointment";

    protected $fillable = [
        'date', 'objectives', 'clinic_history', 'antropometrics', 'observations', 'food_diary', 'id', 'patientId', 'nutritionistId'
    ];

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
