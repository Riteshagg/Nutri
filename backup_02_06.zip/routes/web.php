<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();


Route::group(['middleware' => ['auth']], function() {

    Route::get('/dashboard', 'HomeController@index')->name('dashboard');

    Route::resource('roles','RoleController');
    Route::resource('users','UserController');

    Route::get('/change-password', 'UserController@change_password')->name('change_password');
    Route::post('/update-password', 'UserController@update_password')->name('update_password');


    Route::get('/nutritionist-list', 'NutritionistController@index')->name('nutritionist_list');
    Route::get('/nutritionist-add', 'NutritionistController@create')->name('nutritionist_add');
    Route::post('/nutritionist-save', 'NutritionistController@save_user')->name('nutritionist_save');

    Route::get('/patients', 'PatientController@index')->name('patientlist');
    Route::get('/patients-add', 'PatientController@create')->name('patientadd');
    Route::post('/patients-store', 'PatientController@store')->name('patientstore');
    Route::get('/ajaxpatients', 'PatientController@ajaxHandler')->name('ajaxpatient');

    Route::get('/appointments', 'AppointmentController@appointment')->name('appointments');
    Route::get('/online-appointments', 'AppointmentController@onlineAppointment')->name('online_appointments');

});




